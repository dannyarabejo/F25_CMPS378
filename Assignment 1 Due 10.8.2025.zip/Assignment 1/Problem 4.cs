﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1_Problem_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****** Welcome to LADWP Utility Bill Calculator ******\n");

            //  askig the user
            string name = ReadString("Enter your name: ");
            double kwh = ReadDouble("Enter electricity usage in kWh: ", 0);
            double hcf = ReadDouble("Enter water usage in HCF: ", 0);

            Console.WriteLine();

            //   determining tiered rates
            double elecRate = GetElectricRate(kwh);   // per kWh
            double waterRate = GetWaterRate(hcf);     // per HCF

            //  charges
            double elecCharge = kwh * elecRate;
            double waterCharge = hcf * waterRate;
            double total = elecCharge + waterCharge;

            //    bill display
            Console.WriteLine("=========== LADWP MONTHLY BILL ===========");
            Console.WriteLine("Customer Name:\t" + name);
            Console.WriteLine();
            Console.WriteLine("Electricity Usage:\t" + kwh + " kWh");
            Console.WriteLine("Rate Applied:\t\t" + elecRate.ToString("C2") + " per kWh");
            Console.WriteLine("Electricity Charge:\t" + elecCharge.ToString("C2"));
            Console.WriteLine();
            Console.WriteLine("Water Usage:\t\t" + hcf + " HCF");
            Console.WriteLine("Rate Applied:\t\t" + waterRate.ToString("C2") + " per HCF");
            Console.WriteLine("Water Charge:\t\t" + waterCharge.ToString("C2"));
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("Total Amount Due:\t" + total.ToString("C2"));
            Console.WriteLine("=========================================\n");
            Console.WriteLine("Thank you for using LADWP!");
        }

        static string ReadString(string prompt)
        {
            Console.Write(prompt);
            string s = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(s)) s = "Customer";
            return s.Trim();
        }

        static double ReadDouble(string prompt, double min)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = Console.ReadLine();
                double val;
                if (double.TryParse(s, out val) && val >= min) return val;
                Console.WriteLine("  -> Please enter a number >= " + min + ".\n");
            }
        }

        //    electricity rate 
        static double GetElectricRate(double kwh)
        {
            if (kwh < 200) return 0.13;
            if (kwh < 500) return 0.17;
            if (kwh < 1000) return 0.21;
            return 0.26;
        }

        //  water rate table 
        static double GetWaterRate(double hcf)
        {
            if (hcf < 10) return 2.30;
            if (hcf < 25) return 3.10;
            if (hcf < 40) return 4.20;
            return 5.15;
        }
    }
}

