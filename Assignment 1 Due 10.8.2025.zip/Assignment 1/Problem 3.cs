﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1_Problem_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****** Welcome to the Road Trip Budget Estimator ******\n");

            // asking user
            string name = ReadString("Enter your name: ");

            int days = ReadInt("How many days will your trip be? ", min: 1);

            double totalMiles = ReadDouble("How many miles will you drive in total? ", min: 0.0);

            double mpg = ReadDouble("What is your car's MPG? ", min: 1.0);

            double gasPrice = ReadDouble("What is the average gas price per gallon? ", min: 0.0);

            double hotelPerNight = ReadDouble("What is your nightly hotel cost? ", min: 0.0);

            double dailyFood = ReadDouble("What is your daily food budget? ", min: 0.0);

            Console.WriteLine();

            //  calculating
            double gasNeeded = totalMiles / mpg;
            double gasCost = gasNeeded * gasPrice;

            // no hotel on last night 
            int hotelNights = Math.Max(0, days - 1);
            double hotelCost = hotelPerNight * hotelNights;

            double foodCost = dailyFood * days;

            double totalTripCost = gasCost + hotelCost + foodCost;

            //   summary output
            Console.WriteLine("=========== ROAD TRIP BUDGET SUMMARY ===========");
            Console.WriteLine("Name:\t\t" + name);
            Console.WriteLine("Trip Duration:\t" + days + " days");
            Console.WriteLine("Total Miles:\t" + totalMiles + " miles");
            Console.WriteLine("Fuel Efficiency:\t" + mpg + " MPG");
            Console.WriteLine("Gas Price:\t" + gasPrice.ToString("C2"));
            Console.WriteLine("Hotel Cost/Night:\t" + hotelPerNight.ToString("C2"));
            Console.WriteLine("Daily Food Budget:\t" + dailyFood.ToString("C2"));
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("Gas Needed:\t\t" + gasNeeded.ToString("0.00") + " gallons");
            Console.WriteLine("Estimated Gas Cost:\t" + gasCost.ToString("C2"));
            Console.WriteLine("Estimated Hotel Cost:\t" + hotelCost.ToString("C2"));
            Console.WriteLine("Estimated Food Cost:\t" + foodCost.ToString("C2"));
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("Estimated Trip Total: " + totalTripCost.ToString("C2"));
            Console.WriteLine("================================================\n");
            Console.WriteLine("Thanks for using the Road Trip Budget Estimator!");
        }

        //  input checks
        static string ReadString(string prompt)
        {
            Console.Write(prompt);
            string text = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(text)) text = "Anonymous";
            return text.Trim();
        }

        static int ReadInt(string prompt, int min)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = Console.ReadLine();
                int val;
                if (int.TryParse(s, out val) && val >= min) return val;
                Console.WriteLine("  -> Please enter a whole number >= " + min + ".\n");
            }
        }

        static double ReadDouble(string prompt, double min)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = Console.ReadLine();
                double val;
                if (double.TryParse(s, out val) && val >= min) return val;
                Console.WriteLine("  -> Please enter a number >= " + min + ".\n");
            }
        }
    }
}
