﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1_Problem_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Birthday Date Meaning Generator !\n");

            bool keepGoing = true;
            while (keepGoing)
            {
                int month = ReadInt("Please enter the month of your birthday (1-12): ", 1, 12);

                // read the day then month 
                int day = ReadInt("Please enter the day of your birthday (1-31): ", 1, 31);
                int maxDayInMonth = DaysInMonthBasic(month);
                while (day > maxDayInMonth)
                {
                    Console.WriteLine("  -> That month only goes up to " + maxDayInMonth + ". Try again.\n");
                    day = ReadInt("Please enter the day of your birthday (1-31): ", 1, maxDayInMonth);
                }

                int year = ReadInt("Please enter the year of your birthday (2000-2023): ", 2000, 2023);

                Console.WriteLine();

                string monthName = MonthName(month);
                string monthMeaning = GetMonthMeaning(month);
                string dayMeaning = GetDayMeaning(day);
                string yearMeaning = GetYearMeaning(year);

                Console.WriteLine("The month of " + monthName + " means " + monthMeaning + ".");
                Console.WriteLine("The " + Ordinal(day) + " of " + monthName + " means " + dayMeaning + ".");
                Console.WriteLine("The year of " + year + " means " + yearMeaning + ".");

                Console.Write("\nWould you like to try another one? (Y/N): ");
                string ans = (Console.ReadLine() ?? "").Trim();
                keepGoing = ans.Equals("Y", StringComparison.OrdinalIgnoreCase);
                Console.WriteLine();
            }

            Console.WriteLine("Thanks for playing!");
        }
        //  an integer within [min, max]; keep asking until valid
        static int ReadInt(string prompt, int min, int max)
        {
            while (true)
            {
                Console.Write(prompt);
                string text = Console.ReadLine();

                int value;
                if (int.TryParse(text, out value) && value >= min && value <= max)
                    return value;

                Console.WriteLine("  -> Please enter a whole number between " + min + " and " + max + ".\n");
            }
        }

        // month lengths 
        static int DaysInMonthBasic(int month)
        {
            if (month == 2) return 29;                  
            if (month == 4 || month == 6 || month == 9 || month == 11) return 30;
            return 31;
        }

        static string MonthName(int m)
        {
            string[] names = {
                "", "January","February","March","April","May","June",
                "July","August","September","October","November","December"
            };
            return names[m];
        }

        static string Ordinal(int d)
        {
            int lastTwo = d % 100;
            if (lastTwo == 11 || lastTwo == 12 || lastTwo == 13) return d + "th";

            int last = d % 10;
            if (last == 1) return d + "st";
            if (last == 2) return d + "nd";
            if (last == 3) return d + "rd";
            return d + "th";
        }

        // meanings of the months

        static string GetMonthMeaning(int month)
        {
            switch (month)
            {
                case 1: return "renewal and new beginnings";
                case 2: return "love and connection";
                case 3: return "growth and awakening";
                case 4: return "renewal and hope";
                case 5: return "abundance and joy";
                case 6: return "celebration and adventure";
                case 7: return "freedom and exploration";
                case 8: return "reflection and preparation";
                case 9: return "change and transition";
                case 10: return "celebration and transformation";
                case 11: return "gratitude and contentment";
                case 12: return "reflection and closure";
                default: return "a unique month energy";
            }
        }

        static string GetYearMeaning(int year)
        {
            // identifying years
            if (year <= 2012) return "you are Generation Z";
            return "you are Generation Alpha";
        }

        static string GetDayMeaning(int day)
        {
            // identifying days
            switch (day)
            {
                case 1: return "Self-Starter";
                case 2: return "Solution-Finder";
                case 3: return "Expressive";
                case 4: return "Stable & Rational";
                case 5: return "Flexible";
                case 6: return "Nurturer";
                case 7: return "Seeker";
                case 8: return "Powerful";
                case 9: return "Advocate";
                case 10: return "Leader";
                case 11: return "Aware";
                case 12: return "Creative";
                case 13: return "Conscientious Builder";
                case 14: return "Open-Minded";
                case 15: return "Loving Support";
                case 16: return "Inquisitive";
                case 17: return "Independent Producer";
                case 18: return "Open-Hearted";
                case 19: return "Independent";
                case 20: return "Connector";
                case 21: return "Social";
                case 22: return "Master Builder";
                case 23: return "Zest for Life";
                case 24: return "Heart of Gold";
                case 25: return "Deep Processor";
                case 26: return "Service-Driven";
                case 27: return "Broad-Minded";
                case 28: return "Collaborator";
                case 29: return "Unifier";
                case 30: return "Original Communicator";
                case 31: return "Practical Dreamer";
                default: return "Unique";
            }
        }
    }
}
