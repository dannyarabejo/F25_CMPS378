﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1.Problem_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // asking for input
            Console.Write("Please enter your name: ");
            string name = Console.ReadLine();

            Console.Write("Please enter your age: ");
            int age = int.Parse(Console.ReadLine());

            Console.Write("Please enter your gender (male or female): ");
            string gender = Console.ReadLine();

            Console.Write("Please enter your height in feet: ");
            int heightFeet = int.Parse(Console.ReadLine());

            Console.Write("Please enter your height in inches: ");
            int heightInches = int.Parse(Console.ReadLine());

            Console.Write("Please enter your weight in pounds: ");
            double weight = double.Parse(Console.ReadLine());

            //  change height to inches
            int totalInches = (heightFeet * 12) + heightInches;

            // calculating BMI
            double bmi = 703 * (weight / Math.Pow(totalInches, 2));

            //  bmi status
            string bmiStatus;

            if (bmi < 16)
            {
                bmiStatus = "Severe Thinness";
            }
            else if (bmi >= 16 && bmi < 17)
            {
                bmiStatus = "Moderate Thinness";
            }
            else if (bmi >= 17 && bmi < 18.5)
            {
                bmiStatus = "Mild Thinness";
            }
            else if (bmi >= 18.5 && bmi < 25)
            {
                bmiStatus = "Normal";
            }
            else if (bmi >= 25 && bmi < 30)
            {
                bmiStatus = "Overweight";
            }
            else if (bmi >= 30 && bmi < 35)
            {
                bmiStatus = "Obese Class I";
            }
            else if (bmi >= 35 && bmi < 40)
            {
                bmiStatus = "Obese Class II";
            }
            else
            {
                bmiStatus = "Obese Class III";
            }

            //   showing results
            Console.WriteLine();
            Console.WriteLine("Hi " + name + ",");
            Console.WriteLine("You are a " + gender + ". You are " + age + " years old.");
            Console.WriteLine("You are currently " + heightFeet + " feet " + heightInches + " inches tall and weigh " + weight + " pounds.");
            Console.WriteLine("Your BMI is " + bmi.ToString("0.00") + ", which is " + bmiStatus + ".");
            Console.WriteLine();
            Console.WriteLine("Thank you for using the BMI Calculator!");
        }
    }
}
