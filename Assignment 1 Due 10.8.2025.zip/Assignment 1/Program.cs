﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1_Problem_5
{
    internal class Program
    {
        // 9.5%
        const double TAX_RATE = 0.095;
        // $15.00 per month
        const double STATIC_IP_COST = 15.00; 
        static void Main(string[] args)
        {
            Console.WriteLine("****** Welcome to AT&T Fiber Internet Billing System ******\n");

            //   inputs
            string name = ReadString("Enter your name: ");
            int speed = ReadPlanSpeed("Select internet plan speed (300 / 500 / 1000 / 2000 / 5000 Mbps): ");
            bool addStatic = ReadYesNo("Would you like to add a static IP? (Y/N): ");

            Console.WriteLine();

            //   price by speed
            double basePrice = GetBasePrice(speed);

            //   optional 
            double staticIpCharge = addStatic ? STATIC_IP_COST : 0.0;

            //   calculations
            double subtotal = basePrice + staticIpCharge;
            double tax = subtotal * TAX_RATE;
            double total = subtotal + tax;

            //   output of bill
            Console.WriteLine("=========== AT&T FIBER BILLING SUMMARY ===========");
            Console.WriteLine("Customer Name:\t" + name);
            Console.WriteLine();
            Console.WriteLine("Plan Speed:\t" + speed + " Mbps");
            Console.WriteLine("Base Price:\t" + basePrice.ToString("C2"));
            Console.WriteLine("Static IP:\t" + staticIpCharge.ToString("C2"));
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("Subtotal:\t" + subtotal.ToString("C2"));
            Console.WriteLine("Tax (9.5%):\t" + tax.ToString("C2"));
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("Total Due:\t" + total.ToString("C2"));
            Console.WriteLine("=========================================\n");
            Console.WriteLine("Thank you for choosing AT&T Fiber!");
        }

        // other helpers

        static string ReadString(string prompt)
        {
            Console.Write(prompt);
            string s = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(s)) s = "Customer";
            return s.Trim();
        }

        static int ReadPlanSpeed(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = Console.ReadLine();
                int val;
                if (int.TryParse(s, out val))
                {
                    if (val == 300 || val == 500 || val == 1000 || val == 2000 || val == 5000)
                        return val;
                }
                Console.WriteLine("  -> Please enter one of these speeds exactly: 300, 500, 1000, 2000, or 5000.\n");
            }
        }

        static bool ReadYesNo(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = (Console.ReadLine() ?? "").Trim().ToUpper();
                if (s == "Y" || s == "YES") return true;
                if (s == "N" || s == "NO") return false;
                Console.WriteLine("  -> Please type Y or N.\n");
            }
        }

        static double GetBasePrice(int speed)
        {
            switch (speed)
            {
                case 300: return 55.00;
                case 500: return 65.00;
                case 1000: return 80.00;
                case 2000: return 110.00;
                case 5000: return 180.00;
                default: return 0.00; 
            }

        }
    }
    }
