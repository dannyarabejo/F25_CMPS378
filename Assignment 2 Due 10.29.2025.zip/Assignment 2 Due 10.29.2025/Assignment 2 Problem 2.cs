﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****** Welcome to Monthly Expense Tracker ******");
            Console.WriteLine();

            //  user's name
            Console.Write("Enter your name: ");
            string userName = Console.ReadLine();

            // variables 
            double totalExpenses = 0;
            int count = 0;
            string highestCategory = "";
            double highestAmount = 0;

            // to keep track of category totals
            Dictionary<string, double> categoryTotals = new Dictionary<string, double>();

            while (true)
            {
                Console.WriteLine();
                Console.Write("Enter expense category (or type 'done' to stop): ");
                string category = Console.ReadLine();

                //  value check
                if (category == "-1" || category.ToLower() == "done")
                    break;

                Console.Write("Enter amount (or -1 to quit): ");
                double amount = double.Parse(Console.ReadLine());

                if (amount == -1)
                    break;

                //  add expense
                totalExpenses += amount;
                count++;

                //  add or update 
                if (categoryTotals.ContainsKey(category))
                {
                    categoryTotals[category] += amount;
                }
                else
                {
                    categoryTotals[category] = amount;
                }

                //  highest spending category
                if (categoryTotals[category] > highestAmount)
                {
                    highestAmount = categoryTotals[category];
                    highestCategory = category;
                }
            }

            //  average expense
            double averageExpense = (count > 0) ? totalExpenses / count : 0;

            //  Summary
            Console.WriteLine();
            Console.WriteLine("=========== MONTHLY EXPENSE SUMMARY ===========");
            Console.WriteLine($"Name:\t\t\t{userName}");
            Console.WriteLine($"Total Entries:\t\t{count}");
            Console.WriteLine($"Total Amount Spent:\t${totalExpenses:F2}");
            Console.WriteLine($"Average Expense:\t${averageExpense:F2}");
            Console.WriteLine($"Highest Spending Category:\t{highestCategory}");
            Console.WriteLine("===============================================");
            Console.WriteLine("Thank you for using the Monthly Expense Tracker!");
        }
    }
}
