﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****** Welcome to Freelance Project Income Tracker ******");
            Console.WriteLine();

            // asking for name
            Console.Write("Enter your name: ");
            string freelancerName = Console.ReadLine();

            // asking for how many projects
            Console.Write("How many projects would you like to enter? ");
            int numProjects = int.Parse(Console.ReadLine());

            // variables
            double totalIncome = 0;
            string highestProjectName = "";
            double highestProjectIncome = 0;

            // looping through projects
            for (int i = 1; i <= numProjects; i++)
            {
                Console.WriteLine();
                Console.WriteLine($"Project #{i}:");

                Console.Write("Enter project name: ");
                string projectName = Console.ReadLine();

                Console.Write("Enter hours worked: ");
                double hoursWorked = double.Parse(Console.ReadLine());

                Console.Write("Enter hourly rate: ");
                double hourlyRate = double.Parse(Console.ReadLine());

                // project income
                double projectIncome = hoursWorked * hourlyRate;

                // to total income
                totalIncome += projectIncome;

                // checking the highest earning project
                if (projectIncome > highestProjectIncome)
                {
                    highestProjectIncome = projectIncome;
                    highestProjectName = projectName;
                }
            }

            // average income
            double averageIncome = totalIncome / numProjects;

            //  Summary
            Console.WriteLine();
            Console.WriteLine("=========== FREELANCE INCOME SUMMARY ===========");
            Console.WriteLine($"Freelancer Name: {freelancerName}");
            Console.WriteLine($"Projects Logged: {numProjects}");
            Console.WriteLine();
            Console.WriteLine($"Total Income: \t\t${totalIncome:F2}");
            Console.WriteLine($"Average Project Income: ${averageIncome:F2}");
            Console.WriteLine($"Highest-Earning Project: {highestProjectName} (${highestProjectIncome:F2})");
            Console.WriteLine("===============================================");
            Console.WriteLine("Thank you for using the Income Tracker!");
        }
    }
    
}
