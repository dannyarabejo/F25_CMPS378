﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz_1
{
    internal class Program
    {
        //  constants and 9.5%
        const decimal tax_rate = 0.095m;        
        const decimal free_dessert = 20.00m;

        // prices without drink - tacos combo, burrito meal, quesadilla special, loaded nachos
        const decimal PRICE_A_NO = 7.00m;       
        const decimal PRICE_B_NO = 8.50m;       
        const decimal PRICE_C_NO = 6.00m;       
        const decimal PRICE_D_NO = 5.75m;       

        // price with drink
        const decimal PRICE_A_YES = 9.00m;
        const decimal PRICE_B_YES = 10.50m;
        const decimal PRICE_C_YES = 8.00m;
        const decimal PRICE_D_YES = 7.75m;

        static void Main(string[] args)
        {
            // making currency look normal 
            CultureInfo.CurrentCulture = CultureInfo.CreateSpecificCulture("en-US");

            //  welcome and menu
            PrintWelcome();
            PrintMenu();

            //   inputs
            string customerName = ReadNonEmpty("Enter your name: ");
            char pkg = ReadPackageCode("Enter your package code (A/B/C/D): ");
            bool withDrink = ReadYesNo("Would you like to add a drink? (Y/N): ");
            int qty = ReadPositiveInt("How many combos would you like? ");

            //   item name and unit price
            string comboName = GetComboName(pkg);
            decimal unitPrice = GetUnitPrice(pkg, withDrink);

            //   calculations
            decimal subtotal = unitPrice * qty;
            decimal tax = subtotal * tax_rate;
            decimal total = subtotal + tax;
            bool getsFreeDessert = subtotal >= free_dessert;

            //    receipt 
            Console.WriteLine();
            Console.WriteLine("============ TACO LOCO RECEIPT ============");
            Console.WriteLine($"Customer Name: {customerName}");
            Console.WriteLine($"Combo Ordered: {comboName}");
            Console.WriteLine($"Drink Included: {(withDrink ? "Yes" : "No")}");
            Console.WriteLine($"Quantity: {qty}");
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine($"Price Per Item: {unitPrice.ToString("C2")}");
            Console.WriteLine($"Subtotal: {subtotal.ToString("C2")}");
            Console.WriteLine();
            Console.WriteLine("CMPS 378: C# Programming");
            Console.WriteLine();
            Console.WriteLine($"Tax (9.5%): {tax.ToString("C2")}");
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine($"Total Cost: {total.ToString("C2")}");

            if (getsFreeDessert)
                Console.WriteLine("Congratulations! You get a free dessert!");

            Console.WriteLine("===========================================");
            Console.WriteLine("Thank you for supporting Taco Loco!");
        }

        // extra code for help

        static void PrintWelcome()
        {
            Console.WriteLine("****** Welcome to Taco Loco POS System ******");
            Console.WriteLine();
        }

        static void PrintMenu()
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("A - 3 Tacos Combo    - $7.00/ $9.00 with drink");
            Console.WriteLine("B - Burrito Meal     - $8.50/ $10.50 with drink");
            Console.WriteLine("C - Quesadilla Special - $6.00/ $8.00 with drink");
            Console.WriteLine("D - Loaded Nachos    - $5.75/ $7.75 with drink");
            Console.WriteLine();
        }

        static string ReadNonEmpty(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = (Console.ReadLine() ?? "").Trim();
                if (!string.IsNullOrWhiteSpace(s))
                    return s;
                Console.WriteLine("Please enter something.");
            }
        }

        static char ReadPackageCode(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = (Console.ReadLine() ?? "").Trim();
                if (s.Length > 0)
                {
                    char c = char.ToUpperInvariant(s[0]);
                    if (c == 'A' || c == 'B' || c == 'C' || c == 'D')
                        return c;
                }
                Console.WriteLine("Invalid package code. Please type A, B, C, or D.");
            }
        }

        static bool ReadYesNo(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = (Console.ReadLine() ?? "").Trim();
                if (s.Length > 0)
                {
                    char c = char.ToUpperInvariant(s[0]);
                    if (c == 'Y') return true;
                    if (c == 'N') return false;
                }
                Console.WriteLine("Please enter Y or N.");
            }
        }

        static int ReadPositiveInt(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = (Console.ReadLine() ?? "").Trim();
                if (int.TryParse(s, out int val) && val > 0)
                    return val;

                Console.WriteLine("Please enter a whole number greater than 0.");
            }
        }

        static string GetComboName(char pkg)
        {
            switch (pkg)
            {
                case 'A': return "3 Tacos Combo";
                case 'B': return "Burrito Meal";
                case 'C': return "Quesadilla Special";
                default: return "Loaded Nachos";
            }
        }

        static decimal GetUnitPrice(char pkg, bool withDrink)
        {
            switch (pkg)
            {
                case 'A': return withDrink ? PRICE_A_YES : PRICE_A_NO;
                case 'B': return withDrink ? PRICE_B_YES : PRICE_B_NO;
                case 'C': return withDrink ? PRICE_C_YES : PRICE_C_NO;
                case 'D': return withDrink ? PRICE_D_YES : PRICE_D_NO;
                default: return 0m; 
            }
        }
    }
    
}
