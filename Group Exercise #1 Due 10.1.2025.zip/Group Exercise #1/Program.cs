﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group_Exercise__1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // gas station name 
            Console.Write("Enter the name of gas station: ");
            string stationName = Console.ReadLine();

            // price 
            Console.Write("Enter the price of gas: ");
            double pricePerGallon = Convert.ToDouble(Console.ReadLine());

            // number of gallons 
            Console.Write("How many gallons: ");
            double gallons = Convert.ToDouble(Console.ReadLine());

            // tax 
            Console.Write("What is the tax percentage for this transaction: ");
            double taxPercent = Convert.ToDouble(Console.ReadLine());

            // solving
            double subtotal = pricePerGallon * gallons;

            // taxes
            double taxAmount = subtotal * (taxPercent / 100.0);

            // total
            double total = subtotal + taxAmount;

            Console.WriteLine(); 

            //  banner 
            string banner = new string('*', 10) + " " + stationName + " " + new string('*', 10);
            Console.WriteLine(banner);

            // clean formatting    
            Console.WriteLine("Gas price: $" + pricePerGallon.ToString("0.00"));
            Console.WriteLine("Number of gallons: " + gallons.ToString("0.##"));
            Console.WriteLine("Tax rate: " + taxPercent.ToString("0.##") + "%");
            Console.WriteLine("Subtotal: $" + subtotal.ToString("0.00"));
            Console.WriteLine("Tax: $" + taxAmount.ToString("0.00"));
            Console.WriteLine("Total: $" + total.ToString("0.00"));

           }
    }
}
